package algoritmoprocesos;

/**
 *
 * @author Jaime Noel López Daniel 0901-18-735
 */
public class AlgoritmoProcesos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Apertura de la ventana gráfica
        Algoritmos Ventana = new Algoritmos();
        Ventana.setVisible(true);
    }
    
}
